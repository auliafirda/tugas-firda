package com.tekkomb.kelompok1.soal2_tagihanwarnet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class halamandua extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halamandua);
    }
}
